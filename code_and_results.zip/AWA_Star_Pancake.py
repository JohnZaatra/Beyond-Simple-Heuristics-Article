import heapq
import math
import time
import random
import tracemalloc

# Calculate the gap heuristic: counts how many times a pancake is larger than the next one
def gap_heuristic(state):
    count = 0
    for i in range(len(state) - 1):
        if state[i] > state[i + 1]:
            count += 1
    return count

# Calculate the breakpoint heuristic: counts inversions and checks if the last pancake is in place
def breakpoint_heuristic(state):
    return sum(1 for i in range(len(state) - 1) if state[i] > state[i + 1]) + (1 if state[-1] != len(state) else 0)

# Calculate the position-based heuristic: measures displacement of pancakes from their sorted positions
def position_based_heuristic(state):
    total_displacement = 0
    sorted_state = sorted(state)
    
    for i, pancake in enumerate(state):
        correct_position = sorted_state.index(pancake)  # Find correct position of the pancake
        total_displacement += abs(i - correct_position)  # Accumulate displacement
        
    return total_displacement

# Calculate the simple average of the three heuristics
def simple_averaging_heuristic(state):
    return (gap_heuristic(state) + breakpoint_heuristic(state) + position_based_heuristic(state)) / 3

# Calculate the weighted average of the three heuristics with given weights
def weighted_averaging_heuristic(state, w1=(1/3), w2=(1/3), w3=(1/3)):
    return w1 * gap_heuristic(state) + w2 * breakpoint_heuristic(state) + w3 * position_based_heuristic(state)

# Return the maximum value among the three heuristics
def max_heuristic(state):
    return max(gap_heuristic(state), breakpoint_heuristic(state), position_based_heuristic(state))

# Generate neighbor states by flipping pancakes from each position
def get_neighbors(state):
    neighbors = []
    for i in range(2, len(state) + 1):
        new_state = state[:i][::-1] + state[i:]  # Flip first i pancakes
        neighbors.append(new_state)
    return neighbors

# Apply an adaptive weight to the heuristic based on the search progress and strategy
def adaptive_weighted_heuristic(state, g, max_g, heuristic_func, adjustment_strategy):
    if adjustment_strategy == "linear":
        progress_ratio = g / max_g if max_g > 0 else 1  # Linear adjustment based on progress
        weight = 1.0 - progress_ratio
    elif adjustment_strategy == "exponential":
        decay_rate = 0.1  # Exponential decay based on progress
        weight = math.exp(-decay_rate * (g / max_g))
    elif adjustment_strategy == "piecewise":
        if g < max_g * 0.25:
            weight = 1.0  # Full weight at early stages
        elif g < max_g * 0.75:
            weight = 0.5  # Half weight at mid stages
        else:
            weight = 0.2  # Low weight at late stages
    else:
        weight = 1.0  # Default weight if no strategy is specified
    
    return weight * heuristic_func(state)  # Return weighted heuristic

# Perform the AWA* search with adaptive weighting, returning the solution path, nodes expanded, and path length
def awa_star_search(start, goal, heuristic_func, adjustment_strategy="linear"):
    open_set = []  # Priority queue to manage exploration
    max_g = 100  # Initial maximum depth of search
    heapq.heappush(open_set, (0 + adaptive_weighted_heuristic(start, 0, max_g, heuristic_func, adjustment_strategy), 0, start, []))
    closed_set = set()  # Closed set to track explored states
    expanded_nodes = 0  # Counter for the number of nodes expanded
    
    while open_set:
        _, g, current, path = heapq.heappop(open_set)  # Pop the state with the lowest cost
        
        if current == goal:  # Check if the goal state is reached
            return path + [current], expanded_nodes, len(path + [current])  # Return the solution path, expanded nodes, and its length
        
        if tuple(current) in closed_set:  # Skip already explored states
            continue
        
        closed_set.add(tuple(current))  # Add current state to closed set
        expanded_nodes += 1  # Increment the counter
        
        for neighbor in get_neighbors(current):  # Generate neighbors
            normalized_neighbor = normalize_state(neighbor)  # Normalize the neighbor state
            if tuple(normalized_neighbor) not in closed_set:  # Check if neighbor is unexplored
                heapq.heappush(open_set, (g + 1 + adaptive_weighted_heuristic(neighbor, g + 1, max_g, heuristic_func, adjustment_strategy), g + 1, normalized_neighbor, path + [current]))  # Push neighbor to the queue
    
    return None, expanded_nodes, 0  # Return 0 as the path length if no solution is found

# Normalize the state by choosing the lexicographically smaller of the state and its reverse
def normalize_state(state):
    return min(state, state[::-1])

# Generate random start states for the pancake problem
def generate_random_start_states(size, num_tests):
    random.seed(10)  # Seed random number generator for reproducibility
    states = []
    for _ in range(num_tests):
        state = list(range(1, size + 1))  # Create a list of pancakes
        random.shuffle(state)  # Shuffle to generate a random state
        states.append(state)
    return states

# Run tests for a specific heuristic, measuring average time, nodes expanded, solution cost, and memory usage
def run_tests_for_heuristic(heuristic_func, start_states, pancake_size):
    total_time = 0
    total_nodes_expanded = 0
    total_solution_cost = 0
    total_memory_usage = 0
    goal = list(range(1, pancake_size + 1))  # Define the goal state
    
    for start in start_states:
        tracemalloc.start()  # Start memory tracking
        start_time = time.time()  # Record start time
        _, expanded_nodes, solution_cost = awa_star_search(start, goal, heuristic_func, adjustment_strategy="exponential")
        elapsed_time = time.time() - start_time  # Calculate elapsed time
        current_memory, peak_memory = tracemalloc.get_traced_memory()  # Get memory usage
        tracemalloc.stop()  # Stop memory tracking
        
        total_time += elapsed_time  # Accumulate total time
        total_nodes_expanded += expanded_nodes  # Accumulate total nodes expanded
        total_solution_cost += solution_cost  # Accumulate total solution cost
        total_memory_usage += peak_memory  # Accumulate total memory usage
    
    avg_time = total_time / len(start_states)  # Calculate average time
    avg_nodes_expanded = total_nodes_expanded / len(start_states)  # Calculate average nodes expanded
    avg_solution_cost = total_solution_cost / len(start_states)  # Calculate average solution cost
    avg_memory_usage = total_memory_usage / len(start_states)  # Calculate average memory usage
    return avg_time, avg_nodes_expanded, avg_solution_cost, avg_memory_usage

if __name__ == "__main__":
    num_tests = 1  # Number of start states to generate
    pancake_size = 11

    print("Generating random start states...\n")
    start_states = generate_random_start_states(pancake_size, num_tests)

    # Test AWA* with Gap Heuristic
    print("Using Adaptive Weighted A* with Gap Heuristic:")
    avg_time_gap, avg_nodes_gap, avg_cost_gap, avg_memory_gap = run_tests_for_heuristic(lambda state: gap_heuristic(state), start_states, pancake_size)
    print("Gap Heuristic - Avg Time:", avg_time_gap, "Avg Nodes Expanded:", avg_nodes_gap, "Avg Solution Cost:", avg_cost_gap, "Avg Memory Usage (bytes):", avg_memory_gap, "\n")

    # Test AWA* with Breakpoint Heuristic
    print("Using Adaptive Weighted A* with Breakpoint Heuristic:")
    avg_time_breakpoint, avg_nodes_breakpoint, avg_cost_breakpoint, avg_memory_breakpoint = run_tests_for_heuristic(lambda state: breakpoint_heuristic(state), start_states, pancake_size)
    print("Breakpoint Heuristic - Avg Time:", avg_time_breakpoint, "Avg Nodes Expanded:", avg_nodes_breakpoint, "Avg Solution Cost:", avg_cost_breakpoint, "Avg Memory Usage (bytes):", avg_memory_breakpoint, "\n")

    # Test AWA* with Position-Based Heuristic
    print("Using Adaptive Weighted A* with Position-Based Heuristic:")
    avg_time_position, avg_nodes_position, avg_cost_position, avg_memory_position = run_tests_for_heuristic(lambda state: position_based_heuristic(state), start_states, pancake_size)
    print("Position-Based Heuristic - Avg Time:", avg_time_position, "Avg Nodes Expanded:", avg_nodes_position, "Avg Solution Cost:", avg_cost_position, "Avg Memory Usage (bytes):", avg_memory_position, "\n")

    # Test AWA* with Simple Averaging Heuristic
    print("Using Adaptive Weighted A* with Simple Averaging Heuristic:")
    avg_time_simple_avg, avg_nodes_simple_avg, avg_cost_simple_avg, avg_memory_simple_avg = run_tests_for_heuristic(lambda state: simple_averaging_heuristic(state), start_states, pancake_size)
    print("Simple Averaging Heuristic - Avg Time:", avg_time_simple_avg, "Avg Nodes Expanded:", avg_nodes_simple_avg, "Avg Solution Cost:", avg_cost_simple_avg, "Avg Memory Usage (bytes):", avg_memory_simple_avg, "\n")

    # Test AWA* with Weighted Averaging Heuristic
    print("Using Adaptive Weighted A* with Weighted Averaging Heuristic:")
    avg_time_weighted_avg, avg_nodes_weighted_avg, avg_cost_weighted_avg, avg_memory_weighted_avg = run_tests_for_heuristic(lambda state: weighted_averaging_heuristic(state, w1=0.3, w2=0.3, w3=0.4), start_states, pancake_size)
    print("Weighted Averaging Heuristic - Avg Time:", avg_time_weighted_avg, "Avg Nodes Expanded:", avg_nodes_weighted_avg, "Avg Solution Cost:", avg_cost_weighted_avg, "Avg Memory Usage (bytes):", avg_memory_weighted_avg, "\n")

    # Test AWA* with Max Heuristic
    print("Using Adaptive Weighted A* with Max Heuristic:")
    avg_time_max, avg_nodes_max, avg_cost_max, avg_memory_max = run_tests_for_heuristic(lambda state: max_heuristic(state), start_states, pancake_size)
    print("Max Heuristic - Avg Time:", avg_time_max, "Avg Nodes Expanded:", avg_nodes_max, "Avg Solution Cost:", avg_cost_max, "Avg Memory Usage (bytes):", avg_memory_max, "\n")
