import heapq
import time
import random
import tracemalloc

# Heuristic that counts the number of gaps where the next pancake is smaller than the current one.
def gap_heuristic(state):
    count = 0
    for i in range(len(state) - 1):
        if state[i] > state[i + 1]:
            count += 1
    return count

# Heuristic that counts gaps plus a check if the last pancake is out of place.
def breakpoint_heuristic(state):
    return sum(1 for i in range(len(state) - 1) if state[i] > state[i + 1]) + (1 if state[-1] != len(state) else 0)

# Heuristic based on the sum of displacements of pancakes from their correct positions.
def position_based_heuristic(state):
    total_displacement = 0
    sorted_state = sorted(state)
    
    for i, pancake in enumerate(state):
        correct_position = sorted_state.index(pancake)
        total_displacement += abs(i - correct_position)
    
    return total_displacement

# Simple averaging heuristic combining gap, breakpoint, and position-based heuristics.
def simple_averaging_heuristic(state): #SAH
    return (gap_heuristic(state) + breakpoint_heuristic(state) + position_based_heuristic(state)) / 3

# Weighted averaging heuristic, where each heuristic is given a specific weight.
def weighted_averaging_heuristic(state, w1=0.3, w2=0.3, w3=0.4): #WAH
    return w1 * gap_heuristic(state) + w2 * breakpoint_heuristic(state) + w3 * position_based_heuristic(state)

# Heuristic that returns the maximum value among the three heuristics.
def max_heuristic(state): #MAH
    return max(gap_heuristic(state), breakpoint_heuristic(state), position_based_heuristic(state))

# Function to generate all possible states by flipping the first 'i' pancakes.
def get_neighbors(state):
    neighbors = []
    for i in range(2, len(state) + 1):
        new_state = state[:i][::-1] + state[i:] # Reverse the first 'i' pancakes
        neighbors.append(new_state)
    return neighbors

# A* search algorithm to find the optimal solution path to sort the pancakes.
def a_star_search(start, goal, heuristic_func):
    open_set = []
    heapq.heappush(open_set, (0 + heuristic_func(start), 0, start, []))  # Push the initial state with its heuristic value
    closed_set = set()
    expanded_nodes = 0  # Counter for the number of nodes expanded
    
    while open_set:
        _, g, current, path = heapq.heappop(open_set)
        
        if current == goal:
            return path + [current], expanded_nodes, len(path + [current])  # Return the solution path, expanded nodes, and its length
        
        if tuple(current) in closed_set:
            continue
        
        closed_set.add(tuple(current))
        expanded_nodes += 1  # Increment the counter
        
        for neighbor in get_neighbors(current):
            normalized_neighbor = normalize_state(neighbor)  # Normalize the neighbor to handle symmetrical cases
            if tuple(normalized_neighbor) not in closed_set:
                # Push the neighbor state with its heuristic value
                heapq.heappush(open_set, (g + 1 + heuristic_func(normalized_neighbor), g + 1, normalized_neighbor, path + [current]))
    
    return None, expanded_nodes, 0  # Return 0 as the path length if no solution is found

# Normalize the state to handle symmetrical cases (reverse states).
def normalize_state(state):
    return min(state, state[::-1])

# Generate random start states for testing.
def generate_random_start_states(size, num_tests):
    random.seed(10)
    states = []
    for _ in range(num_tests):
        state = list(range(1, size + 1))
        random.shuffle(state)  # Shuffle to create a random pancake order
        states.append(state)
    return states

# Run tests using a given heuristic and measure performance.
def run_tests_for_heuristic(heuristic_func, start_states, pancake_size):
    total_time = 0
    total_nodes_expanded = 0
    total_solution_cost = 0
    total_memory_usage = 0
    goal = list(range(1, pancake_size + 1))  # The goal state (sorted pancakes)
    
    for start in start_states:
        tracemalloc.start()  # Start memory tracking
        start_time = time.time()
        _, expanded_nodes, solution_cost = a_star_search(start, goal, heuristic_func)
        elapsed_time = time.time() - start_time
        current_memory, peak_memory = tracemalloc.get_traced_memory()
        tracemalloc.stop()  # Stop memory tracking
        
        # Accumulate statistics across all tests
        total_time += elapsed_time
        total_nodes_expanded += expanded_nodes
        total_solution_cost += solution_cost
        total_memory_usage += peak_memory

    # Compute average statistics
    avg_time = total_time / len(start_states)
    avg_nodes_expanded = total_nodes_expanded / len(start_states)
    avg_solution_cost = total_solution_cost / len(start_states)
    avg_memory_usage = total_memory_usage / len(start_states)
    return avg_time, avg_nodes_expanded, avg_solution_cost, avg_memory_usage

if __name__ == "__main__":
    num_tests = 1
    pancake_size = 11

    print("Generating 5 random start states...\n")
    start_states = generate_random_start_states(pancake_size, num_tests)

    # Test gap_heuristic
    print("Using Gap Heuristic:")
    avg_time_gap, avg_nodes_gap, avg_cost_gap, avg_memory_gap = run_tests_for_heuristic(gap_heuristic, start_states, pancake_size)
    print("Gap Heuristic - Avg Time:", avg_time_gap, "Avg Nodes Expanded:", avg_nodes_gap, "Avg Solution Cost:", avg_cost_gap, "Avg Memory Usage (bytes):", avg_memory_gap, "\n")

    # Test breakpoint_heuristic
    print("Using Breakpoint Heuristic:")
    avg_time_breakpoint, avg_nodes_breakpoint, avg_cost_breakpoint, avg_memory_breakpoint = run_tests_for_heuristic(breakpoint_heuristic, start_states, pancake_size)
    print("Breakpoint Heuristic - Avg Time:", avg_time_breakpoint, "Avg Nodes Expanded:", avg_nodes_breakpoint, "Avg Solution Cost:", avg_cost_breakpoint, "Avg Memory Usage (bytes):", avg_memory_breakpoint, "\n")

    # Test position_based_heuristic
    print("Using Position-Based Heuristic:")
    avg_time_position, avg_nodes_position, avg_cost_position, avg_memory_position = run_tests_for_heuristic(position_based_heuristic, start_states, pancake_size)
    print("Position-Based Heuristic - Avg Time:", avg_time_position, "Avg Nodes Expanded:", avg_nodes_position, "Avg Solution Cost:", avg_cost_position, "Avg Memory Usage (bytes):", avg_memory_position, "\n")

    # Test simple_averaging_heuristic
    print("Using Simple Averaging Heuristic:")
    avg_time_simple_avg, avg_nodes_simple_avg, avg_cost_simple_avg, avg_memory_simple_avg = run_tests_for_heuristic(simple_averaging_heuristic, start_states, pancake_size)
    print("Simple Averaging Heuristic - Avg Time:", avg_time_simple_avg, "Avg Nodes Expanded:", avg_nodes_simple_avg, "Avg Solution Cost:", avg_cost_simple_avg, "Avg Memory Usage (bytes):", avg_memory_simple_avg, "\n")

    # Test weighted_averaging_heuristic
    print("Using Weighted Averaging Heuristic:")
    avg_time_weighted_avg, avg_nodes_weighted_avg, avg_cost_weighted_avg, avg_memory_weighted_avg = run_tests_for_heuristic(lambda state: weighted_averaging_heuristic(state, w1=0.3, w2=0.3, w3=0.4), start_states, pancake_size)
    print("Weighted Averaging Heuristic - Avg Time:", avg_time_weighted_avg, "Avg Nodes Expanded:", avg_nodes_weighted_avg, "Avg Solution Cost:", avg_cost_weighted_avg, "Avg Memory Usage (bytes):", avg_memory_weighted_avg, "\n")

    # Test max_heuristic
    print("Using Max Heuristic:")
    avg_time_max, avg_nodes_max, avg_cost_max, avg_memory_max = run_tests_for_heuristic(max_heuristic, start_states, pancake_size)
    print("Max Heuristic - Avg Time:", avg_time_max, "Avg Nodes Expanded:", avg_nodes_max, "Avg Solution Cost:", avg_cost_max, "Avg Memory Usage (bytes):", avg_memory_max, "\n")

